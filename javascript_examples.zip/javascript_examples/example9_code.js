function showEvent()
{
  alert("Button clicked! " + this.id);
}

// onload handler executed when page is fully loaded
window.onload = function()
{
  var button = document.getElementById("thebutton");
  button.onclick = showEvent;
}