
for(var i = 0; i < 10; ++i)
{
  print(i + "\n");
}

